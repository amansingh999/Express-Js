var express = require('express');
var router = express.Router();

const movieDetails = require('../data/movieDetails');

router.get('/:movieId', (req, res, next)=>{
    const movieId = req.params.movieId;
    const results = movieDetails.find((movie)=>{
      return movie.id == movieId;
    })
    if(!results){
      res.json({})
    }else{
      res.json(results)
    }
});

module.exports = router;
