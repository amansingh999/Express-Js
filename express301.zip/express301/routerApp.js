const express = require('express');
const app = express();
const helmet = require('helmet');
app.use(helmet());

app.use(express.urlencoded());
app.use(express.json());
app.use(express.static('public'));

const router = require('./theRouter');
const userrouter = require('./userRouter');
app.use('/',router)
app.use('/user',userrouter)

app.listen(3000);
