module.exports = {
    clientID: '174dfd10761d387a11a8',
    clientSecret: '0f7c3d6d4a91fd8bbe2454bb0888c27f306aae5c',
    callbackURL: "http://localhost:3000/auth"
}